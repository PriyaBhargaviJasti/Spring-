package com.fis.bankapp.dao;

import java.util.List;

import com.fis.bankapp.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CustomerDao extends JpaRepository<Customer,Integer> {
	
/*	public abstract String addCustomer(Customer customer);

	public abstract String updateCustomer(Customer customer) throws CustomerNotFound;

	public abstract String deleteCustomer(int custId) throws CustomerNotFound;

	public abstract Customer getCustomer(int custId) throws CustomerNotFound;

	public abstract List<Customer> getAllCustomers();
*/
}
