/*
package com.fis.bankapp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.bankapp.exception.CustomerNotFound;
import com.fis.bankapp.model.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addCustomer(Customer customer) {
		entityManager.persist(customer);
		return "Customer Saved Successfully";
	}

	@Override
	public String updateCustomer(Customer customer) throws CustomerNotFound {
		
		entityManager.merge(customer);
		return "Customer Updated Successfully";
	
	
	}
		

	@Override
	public String deleteCustomer(int custId) throws CustomerNotFound {
		if(entityManager.find(Customer.class, custId) != null) {
			entityManager.remove(getCustomer(custId));
			return "Customer Removed Successfully";
	}else {
		throw new CustomerNotFound("Invalid Customer Id");
	}
		
	}

	@Override
	public Customer getCustomer(int custId) throws CustomerNotFound{
		if(entityManager.find(Customer.class, custId) != null) {
			return entityManager.find(Customer.class, custId);
	}else {
		throw new CustomerNotFound("Invalid Customer Id");
	}
	}

	@Override
	public List<Customer> getAllCustomers() {
		TypedQuery<Customer> query = entityManager.createQuery("select c from Customer c", Customer.class);
		return query.getResultList();
	}

	

}
*/
