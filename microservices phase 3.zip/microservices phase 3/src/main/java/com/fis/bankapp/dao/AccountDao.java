package com.fis.bankapp.dao;

import java.util.List;



import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Modifying;

import org.springframework.data.jpa.repository.Query;
 
import com.fis.bankapp.model.Account;
 
public interface AccountDao extends JpaRepository<Account, Long> {
 
	@Query("Update Account  set balance=balance+ ?2 where accNo=?1")

	@Modifying

	 public  void depositIntoBalance(long accNo, double depositAmount);
 
	@Query("Update Account set balance=balance - ?2 where accNo=?1")

	@Modifying

	public  void withdrawFromBalance(long accNo, double withdrawAmount);
 
	

	//@Query("Update Account a1 set a1.accBalance=a1.accBalance-?3 where a1.accNumber=?1 and Update Account a2 set a2.accBalance=a2.accBalance+?3 where a2.accNumber=?2")

	//public abstract String FundTransferAccount(long fromAccount,long toAccount,double amount);

 
}



