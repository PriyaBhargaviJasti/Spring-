package com.fis.bankapp.dao;

import java.util.List;

import com.fis.bankapp.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface TransactionDao extends JpaRepository<Transaction,Integer> {
	
	@Query("select t from Transaction t where t.accNoFrom=?1")
	public abstract List<Transaction> getTransaction(long accNo);

/*	public abstract String addTransaction(Transaction transaction);
	
	public List<Transaction> getTransactions(long AccNoFrom);
	
	public List<Transaction> getAllTransactions();
	*/
}
