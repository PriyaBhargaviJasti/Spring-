package com.fis.bankapp.exception;

public class NotEnoughBalance extends Exception {
	public NotEnoughBalance(String message) {
		super(message);
	}
}
