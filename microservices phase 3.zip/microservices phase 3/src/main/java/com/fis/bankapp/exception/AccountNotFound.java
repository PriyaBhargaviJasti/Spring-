package com.fis.bankapp.exception;

public class AccountNotFound extends Exception {

	public AccountNotFound(String message) {
		super(message);
	}

}
