package com.fis.bankapp.service;

import java.util.List;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapp.model.Account;
import com.fis.bankapp.model.Customer;
import com.fis.bankapp.model.Transaction;
import com.fis.bankapp.dao.AccountDao;
import com.fis.bankapp.exception.AccountNotFound;
import com.fis.bankapp.exception.CustomerNotFound;
import com.fis.bankapp.exception.NotEnoughBalance;


@Service
@Transactional
public class AccountServiceImpl implements AccountService {
	@Autowired
	AccountDao dao;
	
	@Autowired
	TransactionService service;

	@Override
	public String addAccount(Account account) {
		dao.save(account);
		return "Account created successfully";

	}
	
	@Override
	public String updateAccount(Account account) {
		dao.save(account);
		return "Account updated successfully";

	}
	
	@Override
	public String deleteAccount(long accNo) throws AccountNotFound {

		Optional<Account> optional = dao.findById(accNo);
		if(optional.isPresent()) {
			dao.deleteById(accNo);
			return "Account deleted successfully";
		} else {
			throw new AccountNotFound("Invalid Account Number");
		}
	}


	@Override
	public Account getAccount(long accNo) throws AccountNotFound {
		Optional<Account> optional = dao.findById(accNo);
		return optional.get();

	}

	@Override
	public String depositIntoBalance(long accNo, double depositAmount) throws AccountNotFound {
		dao.depositIntoBalance(accNo, depositAmount);
		return "Amount Deposited successfully";	}

	@Override
	public String withdrawFromBalance(long accNo, double withdrawAmount) throws NotEnoughBalance, AccountNotFound {
		dao.withdrawFromBalance(accNo, withdrawAmount);
		return "Amount withdrawn successfully";
	}

	@Override
	public String FundTransfer(long accNoFrom, long accNoTo, double amount, String transType) throws AccountNotFound, NotEnoughBalance{
		dao.depositIntoBalance(accNoTo, amount);
		dao.withdrawFromBalance(accNoFrom, amount);
		//accDao.FundTransferAccount(fromAccNumber, toAccNumber, amount);
		
		Transaction trans=new Transaction(accNoFrom,accNoTo,amount,LocalDateTime.now(),transType);
		
		service.addTransaction(trans);
     	return "Fund Transfered successfully";
	}

}

